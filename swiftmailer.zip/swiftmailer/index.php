<?php
require_once './vendor/autoload.php';

// Create the Transport
$transport = (new Swift_SmtpTransport('smtp.gmail.com', 465))
  ->setUsername('anihuchenna16@gamil.com')
  ->setPassword('nomsky24')
;

// Create the Mailer using your created Transport
$mailer = new Swift_Mailer($transport);

// Create a message
$message = (new Swift_Message('Testing mailer'))
  ->setFrom(['laundry.com' => 'NationExpress24'])
  ->setTo([ 'uchennaanih16@gmail.com' => 'NationExpress24'])
  ->setBody('I hope this mail met you well just testing my mailer...');

// Send the message
$mailer->send($message);



 ?>
